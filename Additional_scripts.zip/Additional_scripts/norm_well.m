function [norm_plate_well,normFact] = norm_well(norm_plate,infectS,wsR,corner,highFact)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% this function normalizes each well of a plate according to the %%% 
%%% highest 10% upper percentile of the well corner                %%%  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
normFact = zeros(96,1);
drops_centers = infectS.params.drops_centers;
norm_plate_well = norm_plate;

for i = 1:length(drops_centers)  
    img_well = norm_plate(drops_centers(i,2)-wsR:drops_centers(i,2)+wsR-1,...
        drops_centers(i,1)-wsR:drops_centers(i,1)+wsR);
    img_corners = img_well([1:corner, end-corner+1:end],[1:corner, end-corner+1:end]);
    normFact(i) = prctile(img_corners(:),90);
    if normFact(i)>highFact % if the factor is high - take only 3 corners (maybe there's a speck in one of them)
        fprintf('recalculate norm factor for well %d\n',i)
        cor(:,1) = reshape(img_well(1:corner, 1:corner),[],1);
        cor(:,2) = reshape(img_well(1:corner,end-corner+1:end),[],1);
        cor(:,3) = reshape(img_well(end-corner+1:end, 1:corner),[],1);
        cor(:,4) = reshape(img_well(end-corner+1:end, end-corner+1:end),[],1);
        [~,takeCorners]= mink(mean(cor),3);
        normFact(i) = prctile(reshape(cor(:,takeCorners),[],1),90);       
    end
    img_well_norm = double(img_well)/normFact(i)*255;
    norm_plate_well(drops_centers(i,2)-wsR:drops_centers(i,2)+wsR-1,...
        drops_centers(i,1)-wsR:drops_centers(i,1)+wsR) = img_well_norm;
end

