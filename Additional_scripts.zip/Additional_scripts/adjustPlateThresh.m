function  adjustPlateThresh(fig,infectStruct,im,init_thresh,thresh_xls,row)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% This function presents a full plate for plate-threshold adjusment, %%%
%%% the selected threshold will be saved in an xls file                %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

img = infectStruct.plaques(im).normalized_plate ;
drops_centers = infectStruct.params.drops_centers;
scrz = get(0,'ScreenSize');
fig.Position =  [scrz(3)*0.1 scrz(4)*0.05 scrz(3)*0.6 scrz(4)*0.85];
ax = axes('Parent',fig,'position',[0.05 0.2  0.9 0.8]);
imshow(img,'Parent',ax);
text(size(img,2)/2-500,250,['Plate ' num2str(im) '  ' infectStruct.FullBacNms.Var1{im}],'color','w','fontSize',14)
hold on;

if nargin<6
    row = im;
end

BW = imbinarize(imgaussfilt(img,5),init_thresh);

[B,L] = bwboundaries(BW);
hold on
plot(drops_centers(:,1), drops_centers(:,2), 'bX','MarkerSize',6);
for k = 1:length(B)
   boundary = B{k};
   plot(boundary(:,2), boundary(:,1), 'r', 'LineWidth', 1)
end

slider = uicontrol('Parent',fig,'Style','slider','Position',[81,100,800,23],...
              'value',init_thresh, 'min',0, 'max',1,'Callback',@updateThresh);
bgcolor = fig.Color;
bl1 = uicontrol('Parent',fig,'Style','text','Position',[50,100,23,23],...
                'String','0','BackgroundColor',bgcolor);
bl2 = uicontrol('Parent',fig,'Style','text','Position',[900,100,23,23],...
                'String','1','BackgroundColor',bgcolor);
bl3 = uicontrol('Parent',fig,'Style','text','Position',[900/2,75,100,23],...
                'String','Threshold','BackgroundColor',bgcolor,'FontSize',16);

closeBut = uicontrol('Style', 'pushButton', ...
        'Position', [900 30 60 40], ...
        'String', 'Close', ...
        'callback', @closeFcn);

resetBut = uicontrol('Style', 'pushButton', ...
        'Position', [30 30 60 40], ...
        'String', 'Reset', ...
        'callback', @resetFcn);
    
sliderValue = slider.Value;

function   thresh = closeFcn(hObject, eventdata, f)
    thresh = slider.Value;     
    writetable(table([im, thresh]),thresh_xls,'range',sprintf('A%d:B%d',row,row),'WriteVariableNames',0)
    closereq(); 

end

function  resetFcn(hObject, eventdata, handles)
    set(slider,  'Value',init_thresh ) ;
    plotCol(init_thresh);
end

function hObject = updateThresh(hObject,eventdata)
    newthresh = hObject.Value;
    plotCol(newthresh);
end

function plotCol(ud)
    thresh = ud;
    BW = imbinarize(imgaussfilt(img,5),thresh);
    [B,L] = bwboundaries(BW);
    imshow(img)
    hold on
    plot(drops_centers(:,1), drops_centers(:,2), 'bX','MarkerSize',6);
    for k = 1:length(B)
       boundary = B{k};
       plot(boundary(:,2), boundary(:,1), 'r', 'LineWidth', 1)
    end        
    hold off 
end

end

