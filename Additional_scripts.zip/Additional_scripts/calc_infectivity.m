function [infectivity] = calc_infectivity(infectS,bac,min_plq)
% function [intensity,plaques] = find_plaques(plate_norm,wellSize,wellsx,wellsy,thresh,isplot)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% this function checks, according to a threshold, in each well how many pxls are below 
% the threshold ("plaque", according to normalized
%  fluoresence images plate_norm.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
infectivity = zeros(96,1);

th = infectS.plaques(bac).well_threshold;

drops_centers = infectS.params.drops_centers;
norm_plate = infectS.plaques(bac).normalized_plate;
ws = infectS.params.wellSize;
for i = 1:length(drops_centers)  
    if infectS.plaques(bac).takeWell(i)<0
        infectivity(i) = NaN;
    else       
        img_well = norm_plate(drops_centers(i,2)-ws:drops_centers(i,2)+ws,...
            drops_centers(i,1)-ws:drops_centers(i,1)+ws);
        perimeters = regionprops(~imbinarize(img_well,th(i)),'Perimeter');
        plqs = find([perimeters.Perimeter]>min_plq);
        pxls_all = regionprops(~imbinarize(img_well,th(i)),'PixelList');
        pxl_list = [];
        for j = plqs
            pxl_list = [pxl_list; pxls_all(j).PixelList];
        end
        if ~isempty(pxl_list)
            infectivity(i) = sum(255 - img_well(sub2ind([ws*2+1 ws*2+1],...
                pxl_list(:,2), pxl_list(:,1))))/255/((2*ws+1)^2);
        else 
            infectivity(i) = 0;
        end
    end
end

