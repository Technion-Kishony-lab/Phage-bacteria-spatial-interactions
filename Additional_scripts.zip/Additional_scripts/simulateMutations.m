function [allMutgenesSimul,allSimulWeights] = simulateMutations(mutTbl,...
    org,pan_g,allMutPltIdx,wghtFactor,phage_genes)
% Through all mutations randomly on the genome and count mutations per gene
f = filesep;
posLength =  mutTbl.genomePos2(allMutPltIdx)- mutTbl.genomePos1(allMutPltIdx);
mutTypes = mutTbl.mutType(allMutPltIdx);
allMutgenesSimulcell = cell(size(posLength,1),1);
simulWeights = struct();
% if org == 2 % if phages - load readable gene list
% %     load(['..' f 'Ecoli-Phage-CoEvolution-Sequencing' f 'phage_genes.mat'],'phage_genes');
%     phage_readable_genes = ['..' f 'input_files' f 'PathwayTables' f 'phage_genes.xlsx'];
%     phage_genes = readablePhageGeneList(phage_readable_genes);
% end
for gn = 1:size(posLength,1)
    newPos = randi(pan_g.len-posLength(gn),1);
    mutType = mutTypes{gn};
    geneNums = assignMutGene(pan_g,newPos,mutType);
    if isempty(geneNums)
        disp(gn)
        disp(newPos)
    end
    gnVec = geneNums.gene1:geneNums.gene2;
    switch org
        case 1
            allMutgenesSimulcell{gn} = {pan_g.CDS(gnVec).gene}';
        case 2
%             allMutgenesSimulcell{gn} = {phage_genes(gnVec).genes}';
            allMutgenesSimulcell{gn} = phage_genes.genes(gnVec);
    end 
    simulWeights(gn).wght = repmat(wghtFactor./max(wghtFactor,posLength(gn)),size(allMutgenesSimulcell{gn},1),1);
end
allMutgenesSimul = cat(1,allMutgenesSimulcell{:});
allSimulWeights = cat(1,simulWeights.wght);
