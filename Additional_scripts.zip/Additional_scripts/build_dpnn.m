function [dpnn] = build_dpnn(org,jump,DPs_path,isolates,...
    numCluster,minClusterSize,pos_margin,dp_mat_location,MutInfo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Plot a normalized coverage map with marks of insertions,deletions, %%%
%%% SNPs and count the weighted number of mutation events per gene,    %%%
%%% compared to a simulation                                           %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f = filesep;
organisms = {'bacteria','phage'};
organism = organisms{org};
nms = isolates.Nms;
switch organism
    case 'bacteria'
        wt_pos = find(contains(nms,'MG-Y'),1);
    case 'phage'
        wt_pos = find(contains(nms,'T7_WT') & ~contains(nms,'old'),1);
end
%% load data into dp

if ~exist('dp','var')
    if ~exist([dp_mat_location f 'DPs_' organism '.mat'],'file')
        fprintf('Reading DPs...');
        for i = length(nms) :-1:1           
            load([DPs_path f 'DP_array_' nms{i} '_bowtie.mat']) ;
            n = size(DPs,1);
            L = floor(n/jump)*jump;
            dp(:,i) = mean(reshape(DPs(1:L),jump,[]),1)' ; % average over a small window of jump basepairs
        end
        fprintf('done\n');
        save([dp_mat_location f 'DPs_' organism '.mat'],'dp');
    else
        fprintf('Loading DPs...');
        load([dp_mat_location f 'DPs_' organism '.mat'])
        fprintf('done\n');  
    end   
end
%% Normalize
% Normalize each isolate to itself:
dp0 = double(dp);
dp0(dp0<=5) = nan;
dpn = double(dp)./nanmedian(dp0,1) ;    
if ~exist([dp_mat_location f 'dpnn' '_' organism '.mat'],'file')
    fprintf('Normalizing  coverage...');
    [dpnn,dpn_wt,wt_nan_ind] = NormCoverage(...
        dpn,wt_pos,MutInfo,jump,pos_margin,...
        numCluster,minClusterSize);
    save([dp_mat_location f 'dpnn' '_' organism '.mat'],'dpnn','dpn_wt','wt_nan_ind','jump');
    fprintf('done.\n')
else
    fprintf('loading normalized DPs...')
    load([dp_mat_location f 'dpnn' '_' organism '.mat'])
    fprintf ('done.\n');
end

end
% Internal functions:
function [dpnn,dpn_wt,wt_nan_ind] = NormCoverage(...
    dpn,wt_pos,MutInfo,jump,pos_margin,...
    numClusters,minClusterSize)
% Normalize each loci across all isolates:
dpnn = zeros(size(dpn));
dpn_wt = dpn(:,wt_pos);
wt_nan_ind = find(any(reshape(dpn_wt(:)<=0.1,size(dpn_wt)),2));

% Remove amplification and deletion areas for clustering
positionsCnv =  [MutInfo.genomePos1(strcmp(MutInfo.mutType,'CNV')),...
    MutInfo.genomePos2(strcmp(MutInfo.mutType,'CNV'))]/jump ;
pos_mask = ones(1,size(dpn,1)); 
pos_mask( any((1:size(dpn,1)) >= (positionsCnv(:,1)-pos_margin) & (1:size(dpn,1)) <= (positionsCnv(:,2)+pos_margin)))=0; 
pos_mask(wt_nan_ind) = 0;
clusters = kmeans((dpn(pos_mask~=0,:))',numClusters,'replicates',20);
notClustered = find(histcounts(clusters(:), (1:max(clusters)+1)) <= minClusterSize);
clustered = find(histcounts(clusters(:), (1:max(clusters)+1)) > minClusterSize);
dpn_wt(wt_nan_ind) = nan;      
dpnn(:,ismember(clusters,notClustered)) = dpn(:,ismember(clusters,notClustered))./nanmedian(dpn_wt,2);
for cls = 1:numel(clustered)
    dpn_cls = dpn(:,ismember(clusters,clustered(cls)));
    dpn_cls(wt_nan_ind) = nan;      
    dpnn(:,ismember(clusters,clustered(cls))) = dpn_cls./nanmedian(dpn_cls,2);
end       

end


