function [plate_norm] = interpolate_plate(image,no_phage_wells,wellSize,X,Y)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% this function gets a fluoresence image of a plaque assay one-well plate and
% locations of spots without phage, calculates an interpolated image without plaques 
% and divide original plate by 
% the interpolated one for fluorescence normalization.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

X_nophage = X(no_phage_wells);
Y_nophage = Y(no_phage_wells);

x = [];
y = [];
% add points without phages:
for i = 1:length(X_nophage)
    x =[x repmat(round(X_nophage(i)-wellSize:20:X_nophage(i)+wellSize),[11 1])];
end
for j = 1:length(Y_nophage)
    y =[y repmat(round(Y_nophage(j)-wellSize:20:Y_nophage(j)+wellSize),[1 11])];
end

x = reshape(x ,[1 size(x,1)*size(x,2)]);
y = reshape(y ,[size(y,1)*size(y,2) 1]);
x = x';
y = y';
% add frame:
%top:
x = [x; reshape(repmat(200:50:4530,5,1),[size(200:50:4530,2)*5 1] ) ];
y = [y reshape(repmat(250:10:299,[1,size(200:50:4530)]),[1 size(200:50:4530,2)*size(250:10:299,2)]) ];
% bottom:    
x = [x; reshape(repmat(200:50:4530,5,1),[size(200:50:4530,2)*5 1] ) ];
y = [y reshape(repmat(3218:10:3267,[1,size(200:50:4530)]),[1 size(200:50:4530,2)*size(3218:10:3267,2)]) ];
%right:
x = [x; reshape(repmat(200:10:249,[size(300:50:3217,2) 1]),[size(300:50:3217,2)*5 1] ) ];
y = [y reshape(repmat(300:50:3217,[1,5]),[1 size(200:10:249,2)*size(300:50:3217,2)]) ];
%left:
x = [x; reshape(repmat(4607:10:4656,[size(486:50:3079,2) 1]),[size(486:50:3079,2)*5 1] ) ];
y = [y reshape(repmat(486:50:3079,[1,5]),[1 size(4607:10:4656,2)*size(486:50:3079,2)]) ];

[xi,yi] = meshgrid( 1:1:5184,1:1:3456);
imageg = imgaussfilt(image,100);
z = [];
for k=1:size(x,1)
    z(k) = imageg(y(k),x(k));
end
zi = griddata(x,y,z,xi,yi);
plate_norm = double(image)./zi;

end

