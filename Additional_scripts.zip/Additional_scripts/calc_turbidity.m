function [turbidity] = calc_turbidity(infectS,bac)
% function [intensity,plaques] = find_plaques(plate_norm,wellSize,wellsx,wellsy,thresh,isplot)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% this function calculates the mean pixel value in each well 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
turbidity = zeros(96,1);

th = infectS.plaques(bac).well_threshold;

drops_centers = infectS.params.drops_centers;
norm_plate = infectS.plaques(bac).normalized_plate;
ws = infectS.params.wellSize;
for i = 1:length(drops_centers)  
    if infectS.plaques(bac).takeWell(i)<0
        turbidity(i) = NaN;
    else       
        img_well = norm_plate(drops_centers(i,2)-ws:drops_centers(i,2)+ws,...
            drops_centers(i,1)-ws:drops_centers(i,1)+ws);
        turbidity(i) = sum(img_well(:))/numel(img_well(:))/255;

    end
end

