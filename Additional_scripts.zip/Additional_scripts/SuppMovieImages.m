function [] = SuppMovieImages(raw_imgs_folder,crop_file,out_imgs_folder,...
    plateSize,A,N,ti,bar_pos,bgCntr,chnl,name_pre)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% make jpg images with time bar for the time lapse video %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f = filesep;

%% time bar position
time_pos = [plateSize-170 (plateSize*2)-120];
barH = 15;
fontSize = 60;
%% make imgs for LRtimelapse
if ~exist(out_imgs_folder,'dir')
    mkdir(out_imgs_folder)
end
numImgs = dir([out_imgs_folder f '*.jpg']);
if size(numImgs,1) < N
    crop_main = load(crop_file);
    imgDir = dir([raw_imgs_folder f '*.CR2']);
    tf = numel(imgDir);
    n = logspace(log10(ti+A),log10(tf+A),N)-A;
    t = round(n);
    % load images
    for im = 1:N
        img = imread([raw_imgs_folder f imgDir(t(im)).name]);
        fprintf('reading image %d/%d\n',im,N)
        if im==1
            bg = img(:,:,chnl);
%             bg(449:487,480:517) = bg(449,480);
%             bg(474:503,1504:1540) = bg(474,1504);
%             bg(1454:1495,459:497) = bg(1454,459);
%             bg(1495:1530,1472:1508) = bg(1495,1472);
            bg(bgCntr(1,1):bgCntr(1,2),bgCntr(1,3):bgCntr(1,4)) = bg(bgCntr(1,1),bgCntr(1,3));
            bg(bgCntr(2,1):bgCntr(2,2),bgCntr(2,3):bgCntr(2,4)) = bg(bgCntr(2,1),bgCntr(2,3));
            bg(bgCntr(3,1):bgCntr(3,2),bgCntr(3,3):bgCntr(3,4)) = bg(bgCntr(3,1),bgCntr(3,3));
            bg(bgCntr(4,1):bgCntr(4,2),bgCntr(4,3):bgCntr(4,4)) = bg(bgCntr(4,1),bgCntr(4,3));
            bg_smth = imgaussfilt(bg,4);
            bg_smth_crp =  bg_smth([crop_main.crop(1,2):crop_main.crop(1,2)+plateSize...
            crop_main.crop(2,2)-plateSize:crop_main.crop(2,2)],...
            [crop_main.crop(1,1):crop_main.crop(1,1)+plateSize...
            crop_main.crop(2,1)-plateSize:crop_main.crop(2,1)]);
        end
        img_crp = img([crop_main.crop(1,2):crop_main.crop(1,2)+plateSize...
            crop_main.crop(2,2)-plateSize:crop_main.crop(2,2)],...
            [crop_main.crop(1,1):crop_main.crop(1,1)+plateSize...
            crop_main.crop(2,1)-plateSize:crop_main.crop(2,1)]);
        
        % substruct background image:
        img_nobg = img_crp(:,:,chnl)-bg_smth_crp;
        % insert test and time bar
        time = [num2str(round((t(im)-1)*10/60,2)) ' hr'];
        img = insertText(img_nobg,time_pos, time,'BoxColor','black','TextColor',[150 150 150],'FontSize',fontSize);
        img = insertShape(img,'Rectangle',[bar_pos max(t) barH],'Color','white','LineWidth',4);
        img = insertShape(img,'FilledRectangle',[bar_pos t(im) barH],'Color','white','LineWidth',4);
        % write img:
        if im<10
            imgNm = sprintf('%s_000%d.jpg',name_pre,im);
        elseif im<100
            imgNm = sprintf('%s_00%d.jpg',name_pre,im);
        elseif im<1000
            imgNm = sprintf('%s_0%d.jpg',name_pre,im);
        else
            imgNm = sprintf('%s_%d.jpg',name_pre,im);
        end
        imwrite(img,[out_imgs_folder f imgNm],'jpg') ;
    end
end
end