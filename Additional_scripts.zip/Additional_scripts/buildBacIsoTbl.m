function [BacIsoTbl] = buildBacIsoTbl(SamplingInfo,pltNms,gBac,pBac,orderBac,WT_bac,...
    seqNmsBac)
bac_sample_table = SamplingInfo;
bac_sample_table.Names(size(SamplingInfo,1)+1) = {WT_bac};
bac_sample_table.plate(size(SamplingInfo,1)+1) = {''};
bac_sample_table.coordinates(size(SamplingInfo,1)+1,:) = [0 0]; 
% Reorder and add information:
bacNmsInTable = reshape(cell2mat(cellfun(@(x) contains(seqNmsBac.Nms(gBac(orderBac)),x),...
    bac_sample_table.Names ,'UniformOutput', false )),numel(seqNmsBac.Nms(gBac(orderBac))),[]);
tableInds = sum(cumprod(bacNmsInTable == 0, 2), 2) + 1;
% coordinates = round(bac_sample_table.coordinates(tableInds,:));
coordinates = [round(bac_sample_table.coordinates_1(tableInds)), ...
    round(bac_sample_table.coordinates_2(tableInds))];
bacNms = strcat(repmat('Bac',numel(seqNmsBac.Nms(gBac(orderBac))),1),...
    arrayfun(@(x) num2str(x),1:numel(seqNmsBac.Nms(gBac(orderBac))),'UniformOutput',false)');
SequenceNms = seqNmsBac.Nms(gBac(orderBac));
infectionIdx = pBac(orderBac);
experiment01 = contains(seqNmsBac.Nms(gBac(orderBac)),'Cont'); % 1 == Cont
experiment = cell(numel(experiment01),1);
experiment(experiment01) = {'Cont'};
experiment(~experiment01) = {'Init'};
experiment(contains(seqNmsBac.Nms(gBac(orderBac)),WT_bac)) = {''};
isoNum01 = cellfun(@(x) strcmp(x(end-1:end),'-B'),seqNmsBac.Nms(gBac(orderBac))); % 1 == isoB
isoNum = cell(numel(isoNum01),1);
isoNum(isoNum01) = {'B'};
isoNum(~isoNum01) = {'A'};
isoNum(contains(seqNmsBac.Nms(gBac(orderBac)),WT_bac)) = {''};
[~,replicateNum] = ismember(bac_sample_table.plate(tableInds),pltNms);
BacIsoTbl = table(bacNms,SequenceNms,infectionIdx,replicateNum,experiment,coordinates,isoNum);

end