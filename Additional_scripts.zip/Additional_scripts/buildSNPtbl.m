function [snpInfoTbl] = buildSNPtbl(refGB,MGV,snp,phageGenes)
snpPos = str2double(snp.Position);
indVec = [cellfun(@(x) min(x),{refGB.CDS.indices}); cellfun(@(x) max(x),{refGB.CDS.indices})]';
Alt = MGV.MutGenVCF.alt(ismember(MGV.Positions(:,2),snpPos),:);
if nargin > 3
    geneNames = phageGenes.genes;
else
    geneNames = {refGB.CDS.gene}';
end
snpInfo = struct();
for s = numel(snp.GeneID):-1:1
    ref = upper(refGB.Sequence(snpPos(s)));
    alt_nt = mode(strtrim(Alt(s,Alt(s,:)~='.' & double(Alt(s,:))~=0))); % Take the more frequent SNP
    snpInfo.Call{s} = [ref alt_nt];
    snpInfo.genomePos1(s) = str2double(snp.Position(s));
    snpInfo.genomePos2(s) = str2double(snp.Position(s));
    snpInfo.InsSeq{s} = '';
%     snpInfo.ORFpos2(s) = 0;
    snpInfo.gene2(s) = 0;
    snpInfo.geneNm2{s} = '';
    snpInfo.Length(s) = snpInfo.genomePos2(s)-snpInfo.genomePos1(s);
    if str2double(snp.Intragene_position(s))==-1  % intergenic
        snpInfo.mutType{s} = 'SNP-intergenic';
        geneDS = find(snpPos(s)<indVec(:,1),1);
        if geneDS==1 % upstream to first gene
            snpInfo.ORFpos1(s) = indVec(geneDS,1)-snpPos(s);
            snpInfo.gene1(s) = geneDS;
            snpInfo.geneNm1{s} = geneNames{geneDS};
        elseif isempty(geneDS) % SNP downstream to last gene
            snpInfo.ORFpos1(s) = 0;
            snpInfo.gene1(s) = 0;
            snpInfo.geneNm1{s} = '';
        else
            isComp = [strcmp(refGB.CDS(geneDS-1).location(1:4),'comp'),...
                strcmp(refGB.CDS(geneDS).location(1:4),'comp')];
            if sum(isComp)==1    
                [dist,tmp] = min([snpPos(s)-indVec(geneDS-1,2),indVec(geneDS,1)-snpPos(s)]);
                closer = geneDS-2+tmp;
                snpInfo.ORFpos1(s) = dist;
                snpInfo.gene1(s) = closer;
                snpInfo.geneNm1{s} = geneNames{closer};
            elseif all(isComp)
                snpInfo.ORFpos1(s) = snpPos(s)-indVec(geneDS-1,2);
                snpInfo.gene1(s) = geneDS-1;
                snpInfo.geneNm1{s} = geneNames{geneDS-1}; 
            else
                snpInfo.ORFpos1(s) = indVec(geneDS,1)-snpPos(s);
                snpInfo.gene1(s) = geneDS;
                snpInfo.geneNm1{s} = geneNames{geneDS}; 
            end
        end
        if ~strcmp(snpInfo.geneNm1{s},'')
            snpInfo.mutName{s} = [snpInfo.geneNm1{s} ':ig'];
        else
            snpInfo.mutName{s} = 'ig';
        end
            
    else
        snpInfo.ORFpos1(s) = str2double(snp.Intragene_position{s});
        snpInfo.gene1(s) = str2double(snp.Gene_(s));
        snpInfo.geneNm1{s} = geneNames{str2double(snp.Gene_(s))};
        aa_pos = mod(snpInfo.ORFpos1(s),3); 
        if aa_pos==0 
            aa_pos = 3;
        end
        if ~strcmp(refGB.CDS(snpInfo.gene1(s)).location(1:4),'comp') % Positive strand?
            refCodon = strcat(refGB.Sequence(double(snpPos(s))-aa_pos+1),...
                refGB.Sequence(snpPos(s)-aa_pos+2),...
                refGB.Sequence(snpPos(s)-aa_pos+3));
            altCodon = refCodon;
            altCodon(aa_pos) = alt_nt;
        else  % Negative strand?
            refCodon = seqrcomplement(fliplr(strcat(refGB.Sequence(snpPos(s)+aa_pos-1),...
                refGB.Sequence(snpPos(s)+aa_pos-2),...
                refGB.Sequence(snpPos(s)+aa_pos-3))));
            altCodon = refCodon;
            altCodon(aa_pos) = seqrcomplement(alt_nt);
        end
        snpInfo.AA{s} = [nt2aa(refCodon,'AlternativeStartCodons', false)...
            nt2aa(altCodon,'AlternativeStartCodons', false)];
        if strcmp(nt2aa(refCodon,'AlternativeStartCodons', false),...
                nt2aa(altCodon,'AlternativeStartCodons', false))
            snpInfo.mutType{s} = 'SNP-Syn';
        else
            snpInfo.mutType{s} = 'SNP-NonSyn';
        end
        snpInfo.mutName{s} = [snpInfo.geneNm1{s} ':' snpInfo.AA{s}(1) ...
            num2str(ceil(snpInfo.ORFpos1(s)/3)) snpInfo.AA{s}(2)];
    end
end
snpInfo.mutName = erase(erase(erase(snpInfo.mutName,'gene '),'possible '),'/helicase [14');
% Assign numbers to mutations with similar names:
[~,~,c_aa] = unique(snpInfo.mutName','stable');
for i = 1:max(c_aa)
    j = find(c_aa==i);
    if numel(j)>1
        orgNm = snpInfo.mutName(j(1));
        for change = 1:numel(j)
            snpInfo.mutName(j(change)) = strcat(orgNm,'(', num2str(change),')');
        end
    end 
    clear j change
end
% Place "mutName" first:
mutNameCol = find(strcmp(fieldnames(snpInfo),'mutName'));
if mutNameCol==numel(fieldnames(snpInfo))
    colOrder = [mutNameCol, 1:mutNameCol-1];
else
    colOrder = [mutNameCol, 1:mutNameCol-1, mutNameCol+1:numel(fieldnames(snpInfo))];
end
snpInfoOrd = orderfields(snpInfo,colOrder);
snpInfoTbl = struct2table(structfun(@transpose,snpInfoOrd,'UniformOutput',false));
end