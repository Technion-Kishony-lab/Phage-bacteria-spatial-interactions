function [ infectS] = adjustWellThresh(infectS,well_thresh_xls,ax)
% plot the infection matrix, click rectangle to open the plate, click the
% well to adjust the threshold

ws = infectS.params.wellSize;
% markerSize = 10;
reduce_factor = 0.9;
min_plq = infectS.params.min_plq; % ignore small detections 
infection_names_bac = table2cell(infectS.FullBacNms);
infection_names_phg = table2cell(infectS.FullPhgNms);
nBac = size(infection_names_bac,1);
nPhg = size(infection_names_phg,1);

% Plot matrix:
infectivityRaw = [infectS.plaques.infectivity];
tmp = unique(sort(reshape(infectivityRaw,1,[])));
log_param = tmp(2);
matrix = log(infectivityRaw+log_param); 
himg = imagesc(matrix,'Parent',ax);
hold on
colormap(ax,flipud(gray))
himg.PickableParts = 'none';
ax.ButtonDownFcn = @mouseClick;
axis([0.5, nBac+0.5, 0.5, nPhg+0.5])        
xticks(1:2:nBac);
yticks(1:2:nPhg);
% ylim([0.5 size(phenMatLog,2)+0.5])
xticklabels(1:2:nBac);
yticklabels(1:2:nPhg)

if isfile(well_thresh_xls)
    well_thresh.thresh = xlsread(well_thresh_xls);
    for bac = 1:size(infectS.plaques,2)
        if ~isfield(infectS.plaques(bac),'well_threshold') ||...
                (isfield(infectS.plaques(bac),'well_threshold') && ...
                isempty(infectS.plaques(bac).well_threshold))
            infectS.plaques(bac).well_threshold = repmat(infectS.plaques(bac).threshold,1,96);
        end
        if ~isempty(well_thresh.thresh)
            bac_lines = find(well_thresh.thresh(:,1)==bac);
            if ~isempty(bac_lines)
                infectS.plaques(bac).well_threshold(well_thresh.thresh(bac_lines,2)) = ...
                    well_thresh.thresh(bac_lines,3);
            end
        end
    end
end

function mouseClick(~,~)  % find correct bacteria and phage to open plate image
    click = get(gca,'CurrentPoint');
    rectangle('Position',[ceil(click(1,1)-0.5)-0.5 ceil(click(1,2)-0.5)-0.5 1 1],'EdgeColor','r');
    bacteria = ceil(click(1,1)-0.5);
    phage = ceil(click(1,2)-0.5);
    plot_plate(bacteria,phage);
end

function plot_plate(bac,phg) % plot normalized infection plate with bwboundaries per well. cyan = defult th, magenta = adjusted th. 
    figure();
    plate_ax = gca;
    plate_ax.PickableParts = 'none';
    curr_plate = infectS.plaques(bac).normalized_plate;
    pimg = imshow(curr_plate*reduce_factor);
    hold on;
    title(sprintf('Bacterial Isolate: %s, Phage Isolate: %s',infection_names_bac{bac},...
        replace(infection_names_phg{phg},'_',' ')));
    ws = infectS.params.wellSize;
    drops_centers = infectS.params.drops_centers;
    for i = 1:96
        init_thresh = infectS.plaques(bac).well_threshold(i);
        clr = 'r';
        rect_clr = 'k';
        if init_thresh ~= infectS.plaques(bac).threshold
            clr = 'b';    
            rect_clr = 'b';
        end
        wl = drops_centers(i,:);
        if i == phg
            linewidth = 4; 
            linestyle = '-';
        else
            linewidth = 0.3; 
            linestyle = '--';
        end
        bwsize = ws*2-20;
        well_img = curr_plate(drops_centers(i,2)-bwsize:drops_centers(i,2)+bwsize,...
        drops_centers(i,1)-bwsize:drops_centers(i,1)+bwsize);
        rectangle('Position',[wl(1)-ws wl(2)-ws 2*ws 2*ws],'EdgeColor',rect_clr,'LineWidth',linewidth, 'LineStyle', linestyle);
        BW = imbinarize(well_img,init_thresh);
%         regionprops(BW,well_img,'PixelValues');
        [B1,~] = bwboundaries(BW);
        for k = 1:length(B1)
            boundary = B1{k};
            boundary(boundary(:,1)==1,:) = []; % delete frame line
            boundary(boundary(:,2)==1,:) = [];
            boundary(boundary(:,1)==size(BW,1),:) = [];
            boundary(boundary(:,2)==size(BW,1),:) = [];
            if length(boundary)>min_plq
                h(i,k) = plot(boundary(:,2)+drops_centers(i,1)-bwsize, boundary(:,1)+drops_centers(i,2)-bwsize, '.','Color',clr,'MarkerSize',1);
            end
        end
        if infectS.inoculation(i) == -1 % no phage inoculation
            plot([wl(1)-ws wl(1)+ws],[wl(2)+ws wl(2)-ws],'--','Color',[0.6 0.6 0.6],'LineWidth',0.3);
            plot([wl(1)-ws wl(1)+ws],[wl(2)-ws wl(2)+ws],'--','Color',[0.6 0.6 0.6],'LineWidth',0.3);
        end
        if isnan(infectS.plaques(bac).infectivity(i))
            plot([wl(1)-ws wl(1)+ws],[wl(2)+ws wl(2)-ws],'--','Color','r','LineWidth',0.3);
            plot([wl(1)-ws wl(1)+ws],[wl(2)-ws wl(2)+ws],'--','Color','r','LineWidth',0.3);            
        end
            
    end 
    hold on
    set(pimg,'PickableParts','visible','HitTest','on','ButtonDownFcn',...
        {@openWell, curr_plate,init_thresh,bac,plate_ax,drops_centers,bwsize,h})    
end

function openWell(~,~,curr_plate,init_thresh,bac,plate_ax,drops_centers,bwsize,h2)
    h = h2;
    click = get(plate_ax,'CurrentPoint');
    meanx = mean(reshape(infectS.params.drops_centers(:,1),[8 12]),1);
    meany = mean(reshape(infectS.params.drops_centers(:,2),[8 12]),2);
    X = []; Y = [];
    for x=1:12
        if click(1,1) > meanx(x)-ws && click(1,1) < meanx(x)+ws
            X = x;
        end
    end
    for y=1:8
        if click(1,2) > meany(y)-ws && click(1,2) < meany(y)+ws
            Y = y;
        end
    end    
    well = (X-1)*8 + Y;      
    f_zoom = figure;
    ax_zoom = gca;
    well_img = curr_plate(drops_centers(well,2)-bwsize:drops_centers(well,2)+bwsize,...
        drops_centers(well,1)-bwsize:drops_centers(well,1)+bwsize);
    imshow(well_img*reduce_factor,'Parent',ax_zoom);
    hold on
    init_thresh = infectS.plaques(bac).well_threshold(well); % in case it was updated recently
    BW = imbinarize(well_img,init_thresh);
    [B,~] = bwboundaries(BW);
    for k = 1:length(B)
        boundary = B{k};
        boundary(boundary(:,1)==1,:) = []; % delete frame line
        boundary(boundary(:,2)==1,:) = [];
        boundary(boundary(:,1)==size(BW,1),:) = [];
        boundary(boundary(:,2)==size(BW,1),:) = [];
        if length(boundary)>min_plq
           plot(boundary(:,2), boundary(:,1), 'r', 'LineWidth', 1);
        end
    end
    slider = uicontrol('Parent',f_zoom,'Style','slider','Position',[75,25,310,23],...
           'value',init_thresh, 'min',0, 'max',1,'Callback',{@updateThresh,bac,click,well_img});
       
     closeBut = uicontrol('Style', 'pushButton', ...
        'Position', [400 25 70 40], ...
        'String', 'Save&Close', ...
        'callback', {@closeFcn,bac,plate_ax});
    
    resetBut = uicontrol('Style', 'pushButton', ...
        'Position', [20 25 40 40], ...
        'String', 'Reset', ...
        'callback', {@resetFcn,bac,click,well_img});

    
sliderValue = slider.Value;

function   thresh = closeFcn(hObject, eventdata,bac,plate_ax)
    thresh = slider.Value;
    delete(h(well,:));
    BW = imbinarize(well_img,thresh);
    [B,~] = bwboundaries(BW);
    for n = 1:length(B)
        bd = B{n};
        bd(find(bd(:,1)==1),:) = []; % delete frame line
        bd(find(bd(:,2)==1),:) = [];
        bd(find(bd(:,1)==size(BW,1)),:) = [];
        bd(find(bd(:,2)==size(BW,1)),:) = [];
        if length(bd)>min_plq
            h(well,n) = plot(plate_ax,bd(:,2)+drops_centers(well,1)-bwsize,...
                bd(:,1)+drops_centers(well,2)-bwsize, '.b','MarkerSize',1);
        end
    end
    rectangle(plate_ax,'Position',[drops_centers(well,1)-ws drops_centers(well,2)-ws 2*ws 2*ws],...
        'EdgeColor','b','LineWidth',0.3, 'LineStyle', '--');
    phg = well;
%     xlsappend(well_thresh_xls,[bac,phg,thresh],1);  
    writematrix([bac,phg,thresh],well_thresh_xls,'WriteMode','append')
    infectS.plaques(bac).well_threshold(phg) = thresh;
    closereq(); 
end

function  resetFcn(hObject, eventdata,bac,click,well_img)
    set(slider,  'Value',init_thresh ) ;
    adjustWellThresh(init_thresh,bac,click,well_img);

end
    
end
function hObject = updateThresh(hObject,eventdata,bac,click,well_img)
    newthresh = hObject.Value;
    adjustWellThresh(newthresh,bac,click,well_img);
end

function adjustWellThresh(thresh,bac,click,well_img)
    ax_zoom = gca;
    imshow(well_img*reduce_factor,'Parent',ax_zoom)
    hold on 
    BW = imbinarize(well_img,thresh);
    [B,~] = bwboundaries(BW);
    for k = 1:length(B)
       boundary = B{k};
       plot(boundary(:,2), boundary(:,1), 'r', 'LineWidth', 1)
    end   
    hold off 
end

clear plqStruct
end
