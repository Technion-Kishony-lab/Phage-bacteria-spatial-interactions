function [PhgIsoTbl] = buildPhgIsoTbl(SamplingInfo,pltNms,gPhg,pPhg,orderPhg,WT_phg,...
    seqNmsPhg,BacIsoTbl)
% Add WT to all_samples_table
phg_sample_table = SamplingInfo;
phg_sample_table.Names(size(SamplingInfo,1)+1) = {WT_phg};
phg_sample_table.plate(size(SamplingInfo,1)+1) = {''};
phg_sample_table.coordinates(size(SamplingInfo,1)+1,:) = [0 0]; 
% Reorder and add information:
phgNmsInCoorTable = reshape(cell2mat(cellfun(@(x) contains(seqNmsPhg.Nms(gPhg(orderPhg)),x),...
    phg_sample_table.Names ,'UniformOutput', false )),numel(seqNmsPhg.Nms(gPhg(orderPhg))),[]);
tableInds = sum(cumprod(phgNmsInCoorTable == 0, 2), 2) + 1;
% coordinates = round(phg_sample_table.coordinates(tableInds,:));
coordinates = [round(phg_sample_table.coordinates_1(tableInds,:)),...
    round(phg_sample_table.coordinates_2(tableInds,:))];
phgNms = strcat(repmat('Phg',numel(seqNmsPhg.Nms(gPhg(orderPhg))),1),...
    arrayfun(@(x) num2str(x),1:numel(seqNmsPhg.Nms(gPhg(orderPhg))),'UniformOutput',false)');
SequenceNms = seqNmsPhg.Nms(gPhg(orderPhg));
infectionIdx = pPhg(orderPhg);
% experiment01 = contains(phgNms,'Cont'); % 1 == Cont
experiment01 = contains(seqNmsPhg.Nms(gPhg(orderPhg)),'Cont'); % 1 == Cont 
experiment = cell(numel(experiment01),1);
experiment(experiment01) = {'Cont'};
experiment(~experiment01) = {'Init'};
experiment(contains(seqNmsPhg.Nms(gPhg(orderPhg)),WT_phg)) = {''};
isoNum01 = cellfun(@(x) strcmp(x(13),'2'),seqNmsPhg.Nms(gPhg(orderPhg))); % 1 == isoB
isoNum = cell(numel(isoNum01),1);
isoNum(isoNum01) = {'B'};
isoNum(~isoNum01) = {'A'};
bacIsoNum01 = cellfun(@(x) strcmp(x(end-1:end),'-B'),seqNmsPhg.Nms(gPhg(orderPhg))); % 1 == isoB
bacIsoNum = cell(numel(bacIsoNum01),1);
bacIsoNum(bacIsoNum01) = {'B'};
bacIsoNum(~bacIsoNum01) = {'A'};
bacIsoNum(contains(seqNmsPhg.Nms(gPhg(orderPhg)),WT_phg)) = {''};
[~,replicateNum] = ismember(phg_sample_table.plate(tableInds),pltNms);
bacSeqNms = cellfun(@(x) strcat('Sample_Bac_',x(15:end)), seqNmsPhg.Nms(gPhg(orderPhg)), 'UniformOutput', false);
[is,ind] = ismember(bacSeqNms,BacIsoTbl.SequenceNms);
bacNms = cell(size(bacSeqNms,1),1);
bacNms(is>0) = BacIsoTbl.bacNms(ind(ind>0));
PhgIsoTbl = table(phgNms,SequenceNms,infectionIdx,replicateNum,experiment,coordinates,bacIsoNum,isoNum,bacNms);

end