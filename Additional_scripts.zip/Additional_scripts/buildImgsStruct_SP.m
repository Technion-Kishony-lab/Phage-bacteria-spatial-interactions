function [] = buildImgsStruct_SP(imgsFolderSP,crop_file_SP,mask_file_SP,singleSPImgs,...
        sngSPMeanFile,movieParamsFile,out_imgs_SP,MinPeakDistance,MinPeakProminence)
f = filesep;
%% Raws files:
% imgsFolderSP = ['..' f 'input_files' f 'coevolution' f '220904_MGY_SP'];
% %% Save path:
% crop_file_SP = ['..' f 'input_files' f 'coevolution' f 'crop_SP.mat'];
% mask_file_SP = ['..' f 'input_files' f 'coevolution' f 'masks_SP.mat'];
% singleSPImgs = ['..' f 'script_data' f 'sngPlt_SP.mat'];
% out_imgs_SP  = ['..' f 'script_data' f 'imgs_SP'];
% sngSPMeanFile = ['..' f 'script_data' f 'sngPltMeanSP.mat'];

%% Parameters
load(movieParamsFile,'chnl','plateSizeSP','xyWin','tWin','A','N','ti');
% chnl = 1; % BW images are taken from the Red channel. 
% plateSizeSP = 1100;
% xyWin = 10; % average pixels on this window size
% tWin = 4; %  intensity is averaged on this sliding time window (tWin X 10min)
A = A(3); % Logarithmic frame rate: parameter in log function [initial, continual]
N = N(3); % number of images in movie [initial, continual]
ti = ti(3); % initial image index in movie [initial, continual]
bar_pos_SP = [plateSizeSP-100 (plateSizeSP*2)-20]; % position of time bar in movies
% plate center for elimination of incoulation in BG
bgCntrSP(1,:) = [801,849,1102,1158];
bgCntrSP(2,:) = [843,877,3915,3962];
bgCntrSP(3,:) = [2726,2769,1070,1119];
bgCntrSP(4,:) = [2738,2767,3899,3946];

%% Manually define the cropped area
rawImgsSP = dir([imgsFolderSP f '*.CR2']); 
sortedNms = natsortfiles({rawImgsSP.name});
lastImage = imread([rawImgsSP(end).folder f sortedNms{end}]);
if ~isfile(crop_file_SP)
    h = figure(1); clf; imshow(lastImage);
    title('Choose crop area');
    [x,y] = ginput_red(2);
    crop = round([x y]);
    save(crop_file_SP,'crop')
    close(h);
else
    cpSP = load(crop_file_SP);
end

%% Crop images, remove background and save
if ~isfile(singleSPImgs)
    % take first image as background
    bg = imread([rawImgsSP(1).folder f  sortedNms{1}]);
    % replace inoculation spots with nearby dark pixel:
    bg(bgCntrSP(1,1):bgCntrSP(1,2),bgCntrSP(1,3):bgCntrSP(1,4)) = bg(bgCntrSP(1,1),bgCntrSP(1,3));
    bg(bgCntrSP(2,1):bgCntrSP(2,2),bgCntrSP(2,3):bgCntrSP(2,4)) = bg(bgCntrSP(2,1),bgCntrSP(2,3));
    bg(bgCntrSP(3,1):bgCntrSP(3,2),bgCntrSP(3,3):bgCntrSP(3,4)) = bg(bgCntrSP(3,1),bgCntrSP(3,3));
    bg(bgCntrSP(4,1):bgCntrSP(4,2),bgCntrSP(4,3):bgCntrSP(4,4)) = bg(bgCntrSP(4,1),bgCntrSP(4,3));
    % smooth bg
    bgSmthM = imgaussfilt(bg,4);
    % crop bg per plate
    sngSP(1).bg = bgSmthM(cpSP.crop(1,2):cpSP.crop(1,2)+plateSizeSP,cpSP.crop(1,1):cpSP.crop(1,1)+plateSizeSP,chnl);
    sngSP(2).bg = bgSmthM(cpSP.crop(1,2):cpSP.crop(1,2)+plateSizeSP,cpSP.crop(2,1)-plateSizeSP:cpSP.crop(2,1),chnl);
    sngSP(3).bg = bgSmthM(cpSP.crop(2,2)-plateSizeSP:cpSP.crop(2,2),cpSP.crop(1,1):cpSP.crop(1,1)+plateSizeSP,chnl);
    sngSP(4).bg = bgSmthM(cpSP.crop(2,2)-plateSizeSP:cpSP.crop(2,2),cpSP.crop(2,1)-plateSizeSP:cpSP.crop(2,1),chnl);
    sngSP(1).imgs = zeros(plateSizeSP+1,plateSizeSP+1,numel(sortedNms),'uint8');
    sngSP(2).imgs = zeros(plateSizeSP+1,plateSizeSP+1,numel(sortedNms),'uint8');
    sngSP(3).imgs = zeros(plateSizeSP+1,plateSizeSP+1,numel(sortedNms),'uint8');
    sngSP(4).imgs = zeros(plateSizeSP+1,plateSizeSP+1,numel(sortedNms),'uint8');
    for i = 1:numel(sortedNms)    
        fprintf('reading SP img %d\n',i);
        img =  imread([rawImgsSP(i).folder f  sortedNms{i}]);
        sngSP(1).imgs(:,:,i) = img(cpSP.crop(1,2):cpSP.crop(1,2)+plateSizeSP,cpSP.crop(1,1):cpSP.crop(1,1)+plateSizeSP,chnl);
        sngSP(2).imgs(:,:,i) = img(cpSP.crop(1,2):cpSP.crop(1,2)+plateSizeSP,cpSP.crop(2,1)-plateSizeSP:cpSP.crop(2,1),chnl);
        sngSP(3).imgs(:,:,i) = img(cpSP.crop(2,2)-plateSizeSP:cpSP.crop(2,2),cpSP.crop(1,1):cpSP.crop(1,1)+plateSizeSP,chnl);
        sngSP(4).imgs(:,:,i) = img(cpSP.crop(2,2)-plateSizeSP:cpSP.crop(2,2),cpSP.crop(2,1)-plateSizeSP:cpSP.crop(2,1),chnl);
    end    
    save(singleSPImgs,'sngSP','-v7.3');
end

%% Make images for timelapse
SuppMovieImages(imgsFolderSP,crop_file_SP,out_imgs_SP,...
    plateSizeSP,A,N,ti,bar_pos_SP,bgCntrSP,chnl,'SP')
%% Manually define a round mask around plates to analyze relevat area
if ~exist(mask_file_SP,'file')
    if ~exist('sngSP','var')
        fprintf('loading singleSPImgs...');
        load(singleSPImgs)
        fprintf('done. \n');
    end
    for pl = 4:-1:1
        figure(pl*20)
        title('Choose 3 points to define a circle')
        imshow(sngSP(pl).imgs(:,:,1))
        cirPnts = ginput_red(3);
        [mask(pl).r,mask(pl).c] = fit_circle_through_3_points(cirPnts);
        close(pl*20);
    end
    minR = min([mask.r]);
    for pl = 4:-1:1
        [xx,yy] = meshgrid(1:size(sngSP(pl).imgs(:,:,1),2),1:size(sngSP(pl).imgs(:,:,1),1));
        mask(pl).mask = hypot(xx - mask(pl).c(1), yy - mask(pl).c(2)) <= minR ;
    end
    save(mask_file_SP,'mask')
else
    load(mask_file_SP,'mask')
end
%% Calculate mean over xy windows and analyze peaks:
if ~exist(sngSPMeanFile,'file')   
    if ~exist('sngSP','var')
        fprintf('loading singlePlateImgsMain...');
        load(singleSPImgs)
        fprintf('done. \n');
    end
    for pl = 4:-1:1
        fprintf('averaging over plate %d\n',pl)
        for t = 1:size(sngSP(pl).imgs,3)
            splittedImg = mat2cell(sngSP(pl).imgs(1:plateSizeSP,1:plateSizeSP,t).*...
                uint8(mask(pl).mask(1:plateSizeSP,1:plateSizeSP)),...
                xyWin*ones(plateSizeSP/xyWin,1),xyWin*ones(plateSizeSP/xyWin,1));
            sngSPMean(pl).imgs(:,:,t) = cellfun(@(x) mean2(x),splittedImg);        
        end
        sngSPMean(pl).timeMean = movmean(permute(reshape(sngSPMean(pl).imgs,...
            (plateSizeSP/xyWin)*(plateSizeSP/xyWin),[]),[2,1]),tWin,1);
        for win = 1:size(sngSPMean(pl).timeMean,2)
            [sngSPMean(pl).pks(win).pks,sngSPMean(pl).pks(win).locs,...
                sngSPMean(pl).pks(win).width,sngSPMean(pl).pks(win).prominence] = ...
                findpeaks(sngSPMean(pl).timeMean(:,win),1:size(sngSPMean(pl).timeMean,1),...
                'MinPeakDistance',MinPeakDistance,'MinPeakProminence',MinPeakProminence);
            sngSPMean(pl).pks(win).numPks = numel(sngSPMean(pl).pks(win).pks);
        end
    end
    save(sngSPMeanFile,'sngSPMean');
end

