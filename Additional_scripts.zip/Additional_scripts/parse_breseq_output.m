function indel_table_sorted = parse_breseq_output(allOutputPath, indel_path,org)
% parse annotated.gd: go over all annotated.gd files. collect all non-SNP
% mutations into a table. unify isolates by mutations and write an xls file with a
% line for each mutation including all isolates with this mutation. (then
% manually edit pathway and relevant genes in a seperate file). 
% relevant lines in gd file start with 3 letters: SNP, SUB, DEL, INS, MOB, AMP, CON, INV
%%
f = filesep;
nms = load(['..' f 'mat_files' f 'NAMES.mat']);
types = {'SNP', 'SUB', 'DEL', 'INS', 'MOB', 'AMP', 'CON', 'INV'};
relevantTypes = 3:8;
outputs = dir([allOutputPath f 'output*']);
%% collect relevant mutations from each isolate
% geneNames = {};
isolates = [];
mutTypeStrs = {};
positions =[];
insSeqs = {};
for iso = 1:numel(outputs)
    % read annotated file into lines:
    lines = {};
    disp(outputs(iso).name)
    fileID = fopen([allOutputPath f outputs(iso).name f 'annotated.gd'],'r');
    tline = fgetl(fileID);
    i = 1;
    while ischar(tline)
        lines{i} = tline;
        tline = fgetl(fileID);
        i = i+1;
    end
    fclose(fileID);
    % collect relevant mutations:
    mutC = 1;
    mutTypeStr = {};
    pos = [];
    insSeq = {};
    for ln = numel(lines):-1:1
        words = strsplit(lines{ln});
        if length(words{1})==3
            mutType = find(strcmp(words{1},types));
            if ismember(mutType,relevantTypes)
                pos(mutC,:) = [str2double(words(5))  str2double(words{contains(words,'end_position')}(14:end)) ] ;
                mutLen = words{6};
                insSeq{mutC} = '';
                switch mutType
                    case 3 % deletion,insertion
                        if isempty(str2num(mutLen)) %#ok<*ST2NM>
                            mutLen = length(mutLen);
                        else
                            mutLen = str2num(mutLen);
                        end
                        if mod(mutLen,3)==0
                            mutTypeStr{mutC} = [types{mutType} '-IF' ];
                        else
                            mutTypeStr{mutC} = [types{mutType} '-FS' ];
                        end   

                    case 4
                        if isempty(str2num(mutLen))
                            mutLen = length(mutLen);
                        else
                            mutLen = str2num(mutLen);
                        end
                        if mod(mutLen,3)==0
                            mutTypeStr{mutC} = [types{mutType} '-IF' ];
                        else
                            mutTypeStr{mutC} = [types{mutType} '-FS' ];
                        end
                        insSeq{mutC} = words{6};
                        
                    case 5 % IS MOB
                        mutTypeStr{mutC} = [types{mutType} '-' words{6}];
                    case 6 % amplification
                        mutTypeStr{mutC} = types{mutType};
                    otherwise
                        fprintf('mutation type without definition %s\n',types{mutType})
                        mutTypeStr{mutC} = types{mutType};
                end
            mutC = mutC +1;
            end
        end
    end
    % add to the general relevant mutations list:
    if ~isempty(mutTypeStr)
        switch org
            case 'bac'
                iso_ord = find(strcmp(nms.NAMES.bacteria,replace(outputs(iso).name,'output_','')));
            case 'phg'
                iso_ord = find(strcmp(nms.NAMES.phage,replace(outputs(iso).name,'output_','')));
                if isempty(iso_ord)
                    disp(outputs(iso).name)
                end
        end
        isolates = [isolates;repmat(iso_ord,size(pos,1),1)];
        mutTypeStrs = [mutTypeStrs; mutTypeStr'];
        positions = [positions; pos];  
        insSeqs = [insSeqs; insSeq'];
    else
        fprintf('empty mutTypeStr %d %d\n',iso_ord,ln);
    end

end
all_mutations_table = table(mutTypeStrs,positions(:,1),positions(:,2),insSeqs,isolates);
all_mutations_table.Properties.VariableNames = {'mutType','start','end','insSeq','isolates'};

%% unify similar mutations
[mutations_table,b,c] = unique(all_mutations_table(:,[1,2,3,4]),'stable');
mutations_table.mutIsolates = repmat({''},numel(b) , 1); 
switch org
    case 'bac'
        WTs = find(contains({outputs.name},'MG'));
    case 'phg'
        WTs = find(contains({outputs.name},'T7_WT'));
end
for j = 1:numel(b)
    mutatedIsos = all_mutations_table.isolates(c==j);
    if ~all(ismember(WTs,mutatedIsos))
        mutations_table(j,5) = {replace(replace(num2str(mutatedIsos'),'  ',','),',,',',')};
    end
end
mutations_table.Properties.VariableNames = {'mutType','start','end','insSeq','isolates'};

%% write xls file
indel_table_sorted = sortrows(mutations_table,2);
indel_table_sorted(cellfun(@(x) isempty(x), indel_table_sorted.isolates),:) = [];
writetable(indel_table_sorted,indel_path);

end