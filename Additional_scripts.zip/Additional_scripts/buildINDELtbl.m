function [indelInfoTbl] = buildINDELtbl(refGB,indel,phageGenes)
indVec = [cellfun(@(x) min(x),{refGB.CDS.indices}); cellfun(@(x) max(x),{refGB.CDS.indices})]';
if nargin > 2
    geneNames = phageGenes.genes;
else
    geneNames = {refGB.CDS.gene}';
end
indelInfo = struct();
for in = numel(indel.mutType):-1:1
    ig1 = 0;
    ig2 = 0;
    tp = indel.mutType{in}(1:3);
    indelInfo.genomePos1(in) = indel.start(in);
    indelInfo.genomePos2(in) = indel.end(in);
    indelInfo.Length(in)  = indel.end(in)- indel.start(in)+1;
    indelInfo.InsSeq{in} = indel.insSeq{in};
%     indelInfo.ORFpos2(in) = 0;
    indelInfo.AA{in} = '';
    indelInfo.Call{in} = '';
    g1 = find(indel.start(in)>indVec(:,1) &...
        indel.start(in)<indVec(:,2),1);
    g2 = find(indel.end(in)>indVec(:,1) &...
        indel.end(in)<indVec(:,2),1);
    if isempty(g1)
        g1 = find(indel.start(in)<indVec(:,1),1); % intergenic
        if isempty(g1)
            g1 = size(indVec,1);
        end
        ig1 = 1;
    end
    if isempty(g2)      
        g2 = find(indel.end(in)<indVec(:,1),1); % intergenic
        if isempty(g2)
            g2 = size(indVec,1);
        end
        ig2 = 1;
    end

    if ig1==1 && ig2==1 && g1==g2 %intergenic
        indelInfo.mutType{in} = [indel.mutType{in}(1:3) '-intergenic'];
        if g1==1
            indelInfo.ORFpos1(in) = indVec(g1,1)-indel.start(in);
            indelInfo.gene1(in) = g1;
            indelInfo.geneNm1{in} = geneNames{g1};
        else  
            isComp = [strcmp(refGB.CDS(g1-1).location(1:4),'comp'),...
                strcmp(refGB.CDS(g1).location(1:4),'comp')];
            if g2 == size(indVec,1) % SNP downstream to last gene
                indelInfo.ORFpos1(in) = 0;
                indelInfo.gene1(in) = 0;
                indelInfo.geneNm1{in} = '';
            else
                if sum(isComp)==1    
                    [dist,tmp] = min([indel.start(in)-indVec(g1-1,2),indVec(g1,1)-indel.start(in)]);
                    closer = g1-2+tmp;
                    indelInfo.ORFpos1(in) = dist;
                    indelInfo.gene1(in) = closer;
                    indelInfo.geneNm1{in} = geneNames{closer};
                elseif all(isComp)
                    indelInfo.ORFpos1(in) = indel.start(in)-indVec(g1-1,2);
                    indelInfo.gene1(in) = g1-1;
                    indelInfo.geneNm1{in} = geneNames{g1-1}; 
                else
                    indelInfo.ORFpos1(in) = indVec(g1,1)-indel.start(in);
                    indelInfo.gene1(in) = g1;
                    indelInfo.geneNm1{in} = geneNames{g1}; 
                end
            end
        end
        indelInfo.gene2(in) = 0;
        indelInfo.geneNm2{in} = '';
        switch tp
            case 'DEL'
                indelInfo.mutName{in} = [indelInfo.geneNm1{in} ':D,ig'];
            case 'MOB'
                indelInfo.mutName{in} = [indelInfo.geneNm1{in} ':IS,ig'];
            case 'INS'
                indelInfo.mutName{in} = [indelInfo.geneNm1{in} ':I,ig'];
        end
                
    elseif ig1~=1 && ig2~=1 && g1==g2 % inside gene % check this fix

        isComp = strcmp(refGB.CDS(g1).location(1:4),'comp');
        indelInfo.mutType{in} = indel.mutType{in};
        indelInfo.gene1(in) = g1;
        indelInfo.geneNm1{in} = geneNames{g1};
        if isComp
            indelInfo.ORFpos1(in) = indVec(g1,2) - indel.end(in);
        else
            indelInfo.ORFpos1(in) = indel.start(in) - indVec(g1,1) ;
        end
        indelInfo.gene2(in) = 0;
        indelInfo.geneNm2{in} = '';
        
        switch tp       
            case 'DEL'
                if mod(indelInfo.Length(in),3)==0
                    iffs = 'if';
                else
                    iffs = 'fs';
                end
                indelInfo.mutName{in} = [indelInfo.geneNm1{in} ':D,' iffs];
            case 'MOB'
                indelInfo.mutName{in} = [indelInfo.geneNm1{in} ':IS'];
            case 'INS'
                if mod(length(indelInfo.InsSeq{in}),3)==0
                    iffs = 'if';
                else
                    iffs = 'fs';
                end
                indelInfo.mutName{in} = [indelInfo.geneNm1{in} ':I,' iffs];
        end
        
    elseif g1~=g2 %multiple genes
        indelInfo.mutType{in} = [indel.mutType{in}(1:3) '-multiple'];
        indelInfo.gene1(in) = g1;
        indelInfo.geneNm1{in} = geneNames{g1};
        indelInfo.gene2(in) = g2;
        indelInfo.geneNm2{in} = geneNames{g2};
        indelInfo.ORFpos1(in) = 0;

        switch tp
            case 'DEL'
                indelInfo.mutName{in} = [indelInfo.geneNm1{in} '-' strtrim(indelInfo.geneNm2{in}) ':D'];
            case 'MOB'
                indelInfo.mutName{in} = [indelInfo.geneNm1{in} '-' strtrim(indelInfo.geneNm2{in}) ':IS'];
        end
    end
end
indelInfo.mutName = erase(erase(erase(indelInfo.mutName,'gene '),'possible '),'/helicase [14');

% Assign numbers to mutations with similar names:
[~,~,c_aa] = unique(indelInfo.mutName','stable');
for i = 1:max(c_aa)
    j = find(c_aa==i);
    if numel(j)>1
        orgNm = indelInfo.mutName(j(1));
        for change = 1:numel(j)
            indelInfo.mutName(j(change)) = strcat(orgNm,'(', num2str(change),')');
        end
    end 
    clear j change
end

% Place "mutName" first:
mutNameCol = find(strcmp(fieldnames(indelInfo),'mutName'));
if mutNameCol==numel(fieldnames(indelInfo))
    colOrder = [mutNameCol, 1:mutNameCol-1];
else
    colOrder = [mutNameCol, 1:mutNameCol-1, mutNameCol+1:numel(fieldnames(indelInfo))];
end
indelInfoOrd = orderfields(indelInfo,colOrder);
indelInfoTbl = struct2table(structfun(@transpose,indelInfoOrd,'UniformOutput',false));

end