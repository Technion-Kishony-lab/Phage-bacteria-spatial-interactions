function [cnvInfoTbl] = buildCNVtbl(refGB,cnv,isUni,phageGenes)
indVec = [cellfun(@(x) min(x),{refGB.CDS.indices}); cellfun(@(x) max(x),{refGB.CDS.indices})]';
if nargin > 3
    geneNames = phageGenes.genes;
else
    geneNames = {refGB.CDS.gene}';
end
cnvInfo = struct();
for cn = numel(cnv.start):-1:1
    ig1 = 0;
    ig2 = 0;
    cnvInfo.mutType{cn} = 'CN';
    cnvInfo.genomePos1(cn) = cnv.start(cn);
    cnvInfo.genomePos2(cn) = cnv.end(cn);
    cnvInfo.InsSeq{cn} = '';
    cnvInfo.ORFpos1(cn) = 0;
%     cnvInfo.ORFpos2(cn) = 0;
    cnvInfo.AA{cn} = '';    
    cnvInfo.Call{cn} = '';    
    cnvInfo.Length(cn) = cnv.end(cn) - cnv.start(cn);
    g1 = find(cnv.start(cn)>=indVec(:,1) & cnv.start(cn)<=indVec(:,2),1,'last');
    g2 = find(cnv.end(cn)>=indVec(:,1) & cnv.end(cn)<=indVec(:,2),1);
    
    if isempty(g1)
        g1 = find(cnv.start(cn)<indVec(:,1),1); % intergenic
        if isempty(g1)
            g1 = size(indVec,1);
        end
        ig1 = 1;
    end
    if isempty(g2)      
        g2 = find(cnv.end(cn)<indVec(:,1),1); % intergenic
        if isempty(g2)
            g2 = size(indVec,1);
        else
            g2 = g2-1;
        end
        ig2 = 1;
    end
    if ~isUni
        if ig1==0
            g1 = g1+1;
        end
        if ig2==0
            g2 = g2-1;
        end
    end
    cnvInfo.gene1(cn) = g1;
    cnvInfo.geneNm1{cn} = geneNames{g1};
    cnvInfo.gene2(cn) = g2;
    cnvInfo.geneNm2{cn} = geneNames{g2};
    cnvInfo.mutName{cn} = [cnvInfo.geneNm1{cn} '-' cnvInfo.geneNm2{cn} ':CN'];
end    

% Place "mutName" first:
mutNameCol = find(strcmp(fieldnames(cnvInfo),'mutName'));
if mutNameCol==numel(fieldnames(cnvInfo))
    colOrder = [mutNameCol, 1:mutNameCol-1];
else
    colOrder = [mutNameCol, 1:mutNameCol-1, mutNameCol+1:numel(fieldnames(cnvInfo))];
end
cnvInfoOrd = orderfields(cnvInfo,colOrder);

cnvInfoTbl =  struct2table(structfun(@transpose,cnvInfoOrd,'UniformOutput',false));
end