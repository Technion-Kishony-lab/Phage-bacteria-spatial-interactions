function [mutInfo] = assignMutGene(refGB,mutPos,type)
% get a reference genome and mutation position and assign the relevant
% mutated gene
indVec = [cellfun(@(x) min(x),{refGB.CDS.indices}); cellfun(@(x) max(x),{refGB.CDS.indices})]';
mutInfo = [];
switch type(1:2)
    case 'SN'
        % intergenic?
        ig = find(mutPos(1) > indVec(:,1) & mutPos(1) < indVec(:,2),1);
        if isempty(ig)  % intergenic
            geneDS = find(mutPos<indVec(:,1),1);
            if geneDS==1 % upstream to first gene
                mutInfo.gene1 = geneDS;
            elseif isempty(geneDS) % SNP downstream to last gene
                mutInfo.gene1 = size(indVec,1);
            else
                isComp = [strcmp(refGB.CDS(geneDS-1).location(1:4),'comp'),...
                    strcmp(refGB.CDS(geneDS).location(1:4),'comp')];
                if sum(isComp)==1    
                    [~,tmp] = min([mutPos-indVec(geneDS-1,2),indVec(geneDS,1)-mutPos]);
                    closer = geneDS-2+tmp;
                    mutInfo.gene1 = closer;
                elseif all(isComp)
                    mutInfo.gene1 = geneDS-1;
                else
                    mutInfo.gene1 = geneDS;
                end
            end

        else
            mutInfo.gene1 = ig;
        end
        mutInfo.gene2 = mutInfo.gene1;
        
    case 'CN'
        ig1 = 0;
        ig2 = 0;
        isUni = 0;
        cnv.start = min(mutPos);
        cnv.end = max(mutPos);
        g1 = find(cnv.start>=indVec(:,1) & cnv.start<=indVec(:,2),1,'last');
        g2 = find(cnv.end>=indVec(:,1) & cnv.end<=indVec(:,2),1);

        if isempty(g1)
            g1 = find(cnv.start<indVec(:,1),1); % intergenic
            if isempty(g1)
                g1 = size(indVec,1);
            end
            ig1 = 1;
        end
        if isempty(g2)      
            g2 = find(cnv.end<indVec(:,1),1); % intergenic
            if isempty(g2)
                g2 = size(indVec,1);
            else
                g2 = g2-1;
            end
            ig2 = 1;
        end
        if ~isUni
            if ig1==0
                g1 = g1+1;
            end
            if ig2==0
                g2 = g2-1;
            end
        end
        mutInfo.gene1 = g1;
        mutInfo.gene2 = g2;
              
    case {'DE','MO','IN'}
        ig1 = 0;
        ig2 = 0;
        indel.start = min(mutPos);
        indel.end = max(mutPos);
        g1 = find(indel.start>indVec(:,1) &...
        indel.start<indVec(:,2),1);
        g2 = find(indel.end>indVec(:,1) &...
            indel.end<indVec(:,2),1);
        if isempty(g1)
            g1 = find(indel.start<indVec(:,1),1); % intergenic
            if isempty(g1)
                g1 = size(indVec,1);
            end
            ig1 = 1;
        end
        if isempty(g2)      
            g2 = find(indel.end<indVec(:,1),1); % intergenic
            if isempty(g2)
                g2 = size(indVec,1);
            end
            ig2 = 1;
        end

        if ig1==1 && ig2==1 && g1==g2 %intergenic
            if g1==1
                mutInfo.gene1 = g1;
            else  
                isComp = [strcmp(refGB.CDS(g1-1).location(1:4),'comp'),...
                    strcmp(refGB.CDS(g1).location(1:4),'comp')];
                if g2 == size(indVec,1) %  downstream to last gene
                    mutInfo.gene1 = size(indVec,1);
                else
                    if sum(isComp)==1    
                        [~,tmp] = min([indel.start-indVec(g1-1,2),indVec(g1,1)-indel.start]);
                        closer = g1-2+tmp;
                        mutInfo.gene1 = closer;
                    elseif all(isComp)
                        mutInfo.gene1 = g1-1;
                    else
                        mutInfo.gene1 = g1;
                    end
                end
            end
            mutInfo.gene2 = mutInfo.gene1;
        elseif ig1~=1 && ig2~=1 && g1==g2 % inside gene
            mutInfo.gene1 = g1;
            mutInfo.gene2 = mutInfo.gene1;
        elseif g1~=g2 %multiple genes
            mutInfo.gene1 = g1;
            mutInfo.gene2 = g2;
        end
        
end
     
end
        