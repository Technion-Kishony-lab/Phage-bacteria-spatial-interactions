function [sngPlt,sngPltMean] = buildImgsStruct(raw_imgs,crop_file,mask_save_loc,singlePlateImgsFile,...
    singlePlateMeanFile,plateSize,chnl,xyWin,tWin,MinPeakDistance,MinPeakProminence)

f = filesep;

%% Load image crop coordinate, to crop full images to 4 images (1 per plate)
load(crop_file,'crop');
%% Raw images:
all_imgs = dir([raw_imgs f '*.CR2']);
%% Collect all images into a struct
% Make 4 background images (per plate, remove inoculated bacteria in the center at T0) :
bg = imread([raw_imgs f all_imgs(1).name]);
bg(817:854,1217:1257,chnl) = bg(817,1217,chnl);
bg(840:871,3703:3741,chnl) = bg(840,3703,chnl);
bg(2501:2540,1179:1240,chnl) = bg(2501,1179,chnl);
bg(2540:2578,3664:3710,chnl) = bg(2540,3664,chnl);
bgSmth = imgaussfilt(bg,4);
sngPlt(1).bg = bgSmth(crop(1,2):crop(1,2)+plateSize,crop(1,1):crop(1,1)+plateSize,chnl);
sngPlt(2).bg = bgSmth(crop(1,2):crop(1,2)+plateSize,crop(2,1)-plateSize:crop(2,1),chnl);
sngPlt(3).bg = bgSmth(crop(2,2)-plateSize:crop(2,2),crop(1,1):crop(1,1)+plateSize,chnl);
sngPlt(4).bg = bgSmth(crop(2,2)-plateSize:crop(2,2),crop(2,1)-plateSize:crop(2,1),chnl);
% Read images, crop and add to struct
sngPlt(1).imgs = zeros(plateSize+1,plateSize+1,numel(all_imgs),'uint8');
sngPlt(2).imgs = zeros(plateSize+1,plateSize+1,numel(all_imgs),'uint8');
sngPlt(3).imgs = zeros(plateSize+1,plateSize+1,numel(all_imgs),'uint8');
sngPlt(4).imgs = zeros(plateSize+1,plateSize+1,numel(all_imgs),'uint8');
for i = 1:numel(all_imgs)    
    fprintf('reading img %d\n',i);
    img =  imread([raw_imgs f all_imgs(i).name]);
    sngPlt(1).imgs(:,:,i) = img(crop(1,2):crop(1,2)+plateSize,crop(1,1):crop(1,1)+plateSize,chnl);
    sngPlt(2).imgs(:,:,i) = img(crop(1,2):crop(1,2)+plateSize,crop(2,1)-plateSize:crop(2,1),chnl);
    sngPlt(3).imgs(:,:,i) = img(crop(2,2)-plateSize:crop(2,2),crop(1,1):crop(1,1)+plateSize,chnl);
    sngPlt(4).imgs(:,:,i) = img(crop(2,2)-plateSize:crop(2,2),crop(2,1)-plateSize:crop(2,1),chnl);
end   
fprintf('Saving...\n');
save(singlePlateImgsFile,'sngPlt','-v7.3');

%% Load circle masks per plate (to analyze only plate area)
load(mask_save_loc,'mask')
%% Calculate mean over small spatial windows and find peaks:
for pl = 4:-1:1
    fprintf('averaging over plate %d\n',pl)
    for t = 1:size(sngPlt(pl).imgs,3)
        splittedImg = mat2cell(sngPlt(pl).imgs(1:plateSize,1:plateSize,t).*uint8(mask(pl).mask(1:plateSize,1:plateSize)),...
            xyWin*ones(plateSize/xyWin,1),xyWin*ones(plateSize/xyWin,1));
        sngPltMean(pl).imgs(:,:,t) = cellfun(@(x) mean2(x),splittedImg);        
    end
    sngPltMean(pl).timeMean = movmean(permute(reshape(sngPltMean(pl).imgs,(plateSize/xyWin)*(plateSize/xyWin),[]),[2,1]),tWin,1);
    for win = 1:size(sngPltMean(pl).timeMean,2)
        [sngPltMean(pl).pks(win).pks,sngPltMean(pl).pks(win).locs,...
            sngPltMean(pl).pks(win).width,sngPltMean(pl).pks(win).prominence] = ...
            findpeaks(sngPltMean(pl).timeMean(:,win),1:size(sngPltMean(pl).timeMean,1),...
            'MinPeakDistance',MinPeakDistance,'MinPeakProminence',MinPeakProminence);
        sngPltMean(pl).pks(win).numPks = numel(sngPltMean(pl).pks(win).pks);
    end
end
fprintf('Saving...\n');
save(singlePlateMeanFile,'sngPltMean');

end