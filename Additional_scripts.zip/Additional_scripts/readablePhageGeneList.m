function [phage_genes_table] = readablePhageGeneList(saveLoci)
% make a readable gene list for phage T7 by combining information from
% V01146.1 and NC_001604

V = getgenbank('V01146');
NC = getgenbank('NC_001604');
phage_genes = [];
for cd = 1:size(V.CDS,2)
    cat_note = [];
    curr_note = V.CDS(cd).note;
   for len = 1:size(curr_note)
       cat_note = [cat_note curr_note(len,:)];
   end
   split1 = strsplit(cat_note,';');
   split2 = strsplit(split1{end},',');
   phage_genes(cd).genes = split2{1,1};
   phage_genes(cd).function = NC.CDS(cd).product;
   phage_genes(cd).id_V01146 = V.CDS(cd).protein_id;
   phage_genes(cd).id_NC_001604 = NC.CDS(cd).protein_id;
end

phage_genes_table = struct2table(phage_genes);
writetable(phage_genes_table,saveLoci);
end

