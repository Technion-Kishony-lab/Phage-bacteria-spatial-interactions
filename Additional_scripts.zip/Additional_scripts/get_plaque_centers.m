function drops_centers = get_plaque_centers(imPath, resPath)
    
     fn = dir([imPath '*.CR2']); %***
     ind = find(~cellfun(@isempty, regexp({fn.name}, 'MG', 'once')), 1);
     im = imread([imPath fn(ind).name]);
%function drops_centers = get_drops_centers(imFile, resPath)
%     im = imread(imFile);    
    fh = figure; imshow(fliplr(im));
    title('Press on the four corners of the drops')
    
    resBtn = uicontrol('Style', 'pushbutton', 'String', 'Reset',...
        'Position', [50 10 100 20],...
        'Callback', {@resFun, fh});
    figPos = get(fh, 'Position');
    contBtn = uicontrol('Style', 'pushbutton', 'String', 'Continue',...
        'Position', [figPos(3)-130 10 100 20],...
        'Callback', {@contFun, fh});
    
    drops_centers = find_centers(fh);
    waitfor(fh);
    if exist('resPath', 'var')
        save([resPath '\' 'drops_centers.mat'], 'drops_centers');
    end
end

%%
function drops_centers = find_centers(fh)
[x,y] = ginput_red(4);
[~,xS] = sort(x);
[~,xS] = sort(xS);
[~,yS] = sort(y);
[~,yS] = sort(yS);

corners = zeros(4,2);

for i = 1:4
    if (xS(i)<3 && yS(i)<3)
        corners(1,:) = [x(i),y(i)];
    elseif (xS(i)<3 && yS(i)>2)
        corners(2,:) = [x(i),y(i)];
    elseif (xS(i)>2 && yS(i)<3)
        corners(3,:) = [x(i),y(i)];
    else
        corners(4,:) = [x(i),y(i)];
    end
end

hold on
drops_centers = centPosFun(corners);
center_dots = plot(drops_centers(:,1), drops_centers(:,2), 'r.','MarkerSize',16);
set(fh, 'userData', center_dots);
hold off
end

%% function to find centers of drops
function centPos = centPosFun(corners)
%% accepts 4 corners and retrive position of 96 colonies.

x0 = corners(1,1);
y0 = corners(1,2);

dx = mean([(corners(1,1) - corners(2,1)),(corners(3,1) - corners(4,1))]) /7;
dy = mean([(corners(1,2) - corners(3,2)),(corners(2,2) - corners(4,2))])/11;

xStep = mean([(corners(3,1) - corners(1,1)),(corners(4,1) - corners(2,1))]) /11;
yStep = mean([(corners(2,2) - corners(1,2)),(corners(4,2) - corners(3,2))])/7;

k = 0;
centPos = zeros(96,2);
for j = 0:11
    for i = 0:7
        
        k = k+1;
        centPos(k , :) = round([(x0-dx*i+xStep*j), (y0-dy*j+yStep*i)]);
    end
end
end

%%
function resFun(~,~,fh)
ud = get(fh, 'UserData');
if ~isempty(ud)
    delete(ud);
    set(fh, 'UserData', []);
end
find_centers(fh);
end

%%
function contFun(~,~,fh)
close(fh);
end