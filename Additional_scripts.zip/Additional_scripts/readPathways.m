function [pw,pw_uniq] = readPathways(muts,org,pw_folder,mutPwType)
% Find correspoding biological pathway for each mutation in the pathway
% table
pw = cell(numel(muts),1);
pwall = cell(numel(muts)*4,1);
ind = 1;
f = filesep;
switch org
    case 1
        pathwayFile = [pw_folder f 'pathwayBac' mutPwType '.xlsx'];
    case 2 
        pathwayFile = [pw_folder f 'pathwayPhg' mutPwType '.xlsx'];
end

pwmut = readtable(pathwayFile);
for m = 1:numel(muts)
    mut_split = split(muts{m},'+');
    pws = cell(numel(mut_split),1);
    for sp = 1:numel(mut_split)
        pws{sp} = pwmut.pathway{find(cellfun(@(x) contains(mut_split{sp},x),pwmut.mutation),1)};
    end
    if numel(unique(pws))==1
        pw{m} = pws{1};
        pwall{ind} = pws{1};
        ind = ind+1;
    else
        for i = 1:numel(pws)
            pwall{ind} = pws{i};
            ind = ind+1;
        end        
        pw{m} = pws;
    end  
end
pw_uniq = unique(pwall(1:find(cellfun(@(x) isempty(x), pwall),1)-1));
end