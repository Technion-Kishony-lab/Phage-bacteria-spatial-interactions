function infectStruct = remove_merged_plqs(infectStruct,lids_folder,xls_remove_name )

% mark to be removed merged wells, first col = name; below - wells to remove; 
f = filesep;
infectStruct.lidsFolder = lids_folder;
imgs_folder = infectStruct.imgFolder;
lids_imgs = dir([lids_folder f '*.CR2']);
plaq_imgs = dir([imgs_folder f '*.CR2']);
drops_centers = infectStruct.params.drops_centers;

if ~isfile(xls_remove_name)
    for im = 1:size(lids_imgs,1)
        lid_img = imread([lids_folder f lids_imgs(im).name]);
        if isfile([imgs_folder f lids_imgs(im).name(1:end-4) '_YFP.CR2'])
            plaq_img = imread([imgs_folder f lids_imgs(im).name(1:end-4) '_YFP.CR2']);
        else 
            plaq_img = imread([imgs_folder f lids_imgs(im).name(1:end-4) '_CFP.CR2']);
        end
        fig = figure;
        remove_merged(fig,fliplr(lid_img),fliplr(plaq_img),drops_centers,xls_remove_name,lids_imgs(im).name(1:end-4),im)
        waitfor(fig)

    end
end

% Remove merged plaques from takeWell field
[~,~,remove] = xlsread(xls_remove_name);
for p = 1:size(remove,2)
    plate = string(remove{1,p});
    wells = cell2mat(remove(2:end,p));
    % find index of matching plate name:
    if ~ismissing(plate)
        index = [];
        if str2double(plate)<10
            plate_name_exp = strcat('0', plate, '_[YC]FP.CR2');
        else
            plate_name_exp = strcat(plate, '_[YC]FP.CR2');
        end
        for a = 1:size(plaq_imgs,1)
            lookForPlate = regexpi(plaq_imgs(a).name,plate_name_exp);
            if lookForPlate
                index = a;
                display(plaq_imgs(a).name)
            end
        end
    end
    % change wells to -1 in matrix
    tmp_matrix = infectStruct.plaques(index).takeWell;
    tmp_matrix(wells(wells>0)) = -1;
    tmp_matrix_std = standardizeMissing(tmp_matrix,-1);
    infectStruct.plaques(index).takeWell = tmp_matrix_std;
    
end
end

% Internal function that shows images of lids with marks on the merged wells, for manual selection:
function [data] = remove_merged(fig,lid_img,plaq_img,drops_centers,remove_xls,iso_name,col_num)

data =[];
scrz = get(0,'ScreenSize');
% f = figure;
fig.Position =  [scrz(3)*0.1 scrz(4)*0.1  scrz(3)*0.6 scrz(4)*0.8];
axes('Parent',fig,'position',[0.05 0.2  0.9 0.8]);

closeBut = uicontrol('Style', 'pushButton', ...
        'Position', [900 30 120 40], ...
        'String', 'Close and Save', ...
        'callback', @closeFcn);

plaq_gray = rgb2gray(plaq_img);    
imshow(plaq_gray*2, 'InitialMag', 'fit') ;    
green = cat(3, ones(size(plaq_gray)), zeros(size(plaq_gray)), zeros(size(plaq_gray))); 
hold on 
h = imshow(green); 
hold off 
lid_gray = rgb2gray(lid_img);
set(h, 'AlphaData', lid_gray);    
    
hold on;
p = plot(drops_centers(:,1), drops_centers(:,2), 'gX','MarkerSize',6);
hold on;
set(fig,'ButtonDownFcn',@(~,~)disp('figure'),...
   'HitTest','off')
set(p,'ButtonDownFcn',{@showValueFcn},...
   'PickableParts','all')

function showValueFcn(~, event)
    coordinateSelected =  event.IntersectionPoint(1:2);
    data = [data ;coordinateSelected];
    disp(data)
    plot(coordinateSelected(1),coordinateSelected(2),'ro','MarkerSize',6,'MarkerFaceColor','r');
end

function  closeFcn(~, ~, fig)
    if ~isempty(data)
        wells = find(ismember(drops_centers, data,'rows'));
        s = length(wells);
        writetable(table({iso_name}),remove_xls,'range',sprintf('%s1:%s1',xlscol(col_num),xlscol(col_num)),...
            'WriteVariableNames',0);
        writetable(table(wells),remove_xls,'range',sprintf('%s2:%s%d',xlscol(col_num),xlscol(col_num),s+1),...
            'WriteVariableNames',0);
    end
    closereq(); 
end

end

