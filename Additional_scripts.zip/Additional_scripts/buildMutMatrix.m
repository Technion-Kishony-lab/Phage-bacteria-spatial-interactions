function [mm_uni,mm_org,geneCNVuniPos] = buildMutMatrix(refGB,snp,indel,...
    man_indel,cnv,wt,MGV,minCov,polymorph,wts)
% Thie funciton get paths to all mutation information files and builds a matrix (mm_org)
% with SNPs and additional lines with A for indels and T for CNVs (G for
% ancestral call)
% The function will also generate another matrix (mm) with unifies long CNV events in their
% overlapping areas. 

% SNP mutmat:
mm_col_in_snp = 17;
mm_snp_sp = cell2mat(table2cell(snp(:,mm_col_in_snp)));
mm_snp_N = reshape(mm_snp_sp(~isspace(mm_snp_sp)),size(mm_snp_sp,1),size(mm_snp_sp,2)/2);
% replace N with ancestor call:
mm_snp = mm_snp_N;
for ln = 1:size(mm_snp_N,1)
    mm_snp(ln,mm_snp_N(ln,:)=='N') = mm_snp_N(ln,wt);
end

% Replace 'n' (heterogeneity) in WT phage with the most frequent allele
snpPos = str2double(snp.Position);
if nargin > 9 
    heteroLocPhg = find(any(arrayfun(@(x) contains(x,'n'),mm_snp(:,wts))'));
    for het = 1:numel(heteroLocPhg)
        alt = MGV.MutGenVCF.DP4_alt(MGV.Positions(:,2)==snpPos(heteroLocPhg(het)),wts);
        ref = MGV.MutGenVCF.DP4_ref(MGV.Positions(:,2)==snpPos(heteroLocPhg(het)),wts);
        if  all(alt > ref)
            mm_snp(heteroLocPhg,wts) = phg_MGV.Call(MGV.Positions(:,2)==...
                snpPos(heteroLocPhg(het)),wts);
        elseif  all(alt < ref)
             mm_snp(heteroLocPhg,wts) = repmat(MGV.Ref(MGV.Positions(:,2)==...
                 snpPos(heteroLocPhg(het))),1,numel(alt));
        end
    end
end

% Replace other ns in cases of low coverage or >70% of one allele:
[mut,iso] = ind2sub(size(mm_snp),find(arrayfun(@(x) strcmp(x, 'n'),mm_snp)));
for m = 1:numel(mut)
    ref = double(MGV.MutGenVCF.DP4_ref(MGV.Positions(:,2)==snpPos(mut(m)),iso(m)));
    alt = double(MGV.MutGenVCF.DP4_alt(MGV.Positions(:,2)==snpPos(mut(m)),iso(m)));
    if alt+ref <= minCov
        mm_snp(mut(m),iso(m)) = MGV.Ref(MGV.Positions(:,2)==...
                 snpPos(mut(m)));
    elseif alt/(ref+alt) >= polymorph 
        mm_snp(mut(m),iso(m)) = MGV.MutGenVCF.alt(MGV.Positions(:,2)==...
                 snpPos(mut(m)),iso(m));
    elseif ref/(ref+alt) >= polymorph
        mm_snp(mut(m),iso(m)) = MGV.Ref(MGV.Positions(:,2)==...
                 snpPos(mut(m)));        
    end
end

% indel mutmat:
mm_indel = [];
for idx = size(indel,1):-1:1
    mm_indel(idx,:) = repmat('G',[1 size(mm_snp,2)]);
    isolates = str2num(cell2mat(indel.isolates(idx))); %#ok<*ST2NM>
    mm_indel(idx,isolates) = 'T'; % indel -> T  
end
% man indel mutmat
mm_man_indel = [];
for idx = size(man_indel,1):-1:1
    mm_man_indel(idx,:) = repmat('G',[1 size(mm_snp,2)]);
    isolates = str2num(cell2mat(man_indel.isolates(idx))); %#ok<*ST2NM>
    mm_man_indel(idx,isolates) = 'T'; % indel -> T  
end
% cnv mutmat:
mm_cnv = [];
for idx_cnv = size(cnv,1):-1:1
    mm_cnv(idx_cnv,:) = repmat('G',[1 size(mm_snp,2)]);
    isolates = str2num(cell2mat(cnv.isolates(idx_cnv))); %#ok<*ST2NM>
    mm_cnv(idx_cnv,isolates) = 'A'; % AMP -> A
end

mm_org = [mm_snp;mm_indel;mm_man_indel;mm_cnv];

% Cut and unify overlapping CNVs:
% Cut:
mm_cat_and_uni_cnv_allGenes = repmat('G',size(refGB.CDS,2),size(mm_snp,2));
genePos = [cellfun(@(x) min(x), {refGB.CDS.indices}); cellfun(@(x) max(x), {refGB.CDS.indices}) ]'; 
cnvPos = [cnv.start cnv.end];
for idx = 1:size(mm_cnv,1)           
    isolates = mm_cnv(idx,:)~='G';
    gene1 = find(genePos(:,1) < cnvPos(idx,1) & genePos(:,2) > cnvPos(idx,1),1);    
    gene2 = find(genePos(:,1) < cnvPos(idx,2) & genePos(:,2) > cnvPos(idx,2),1,'last');    
    if isempty(gene1) % start of event is intergenic
        gene1 = find(genePos(:,2) < cnvPos(idx,1),1,'last'); 
        if isempty(gene1) % if event starts before gene 1
            gene1 = 1;
        end
    end
    if isempty(gene2) % end of event is intergenic
        gene2 = find(genePos(:,1) > cnvPos(idx,2),1);  
        if isempty(gene2) % if event end at end of genome
            gene2 = size(refGB.CDS,2);
        end
    end
    if ~isempty(gene1) && gene1 > 1  % count only fully amplified genes
        gene1 = gene1 + 1;
    end
    if  ~isempty(gene2) && gene2 < size(refGB.CDS,2) % count only fully amplified genes
        gene2 = gene2 - 1;
    end
    mm_cat_and_uni_cnv_allGenes(gene1:gene2,isolates) = 'A';
end
[~,~,mm_amp_r] = unique(mm_cat_and_uni_cnv_allGenes,'rows','stable'); 
% Unify:
geneCNVuniPos = [];
[Bamp, Namp, Iamp] = RunLength(mm_amp_r');
start = Iamp(Bamp~=mode(mm_amp_r));
stop = Iamp(Bamp~=mode(mm_amp_r))+Namp(Bamp~=mode(mm_amp_r))-1;
mm_cat_and_uni_cnv = [];
for mt = numel(start):-1:1
    geneCNVuniPos(mt,:) = [min(refGB.CDS(start(mt)).indices) max(refGB.CDS(stop(mt)).indices)];
    mm_cat_and_uni_cnv(mt,:) = mm_cat_and_uni_cnv_allGenes(start(mt),:);
end

mm_uni = [mm_snp;mm_indel;mm_man_indel;mm_cat_and_uni_cnv];

end


