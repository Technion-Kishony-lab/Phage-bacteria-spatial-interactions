function [infectStruct] = buildInfectionMat(infect_imgs_folder,save_folder,...
    inoc_plate_file,name_order_file,WT_pos,lids_folder,xls_remove_name,plate_thresh_xls,...
    plateWT1_thresh_xls,well_thresh_xls,...
    wellSize,min_plq,exp,infectStructFile,fixPltTh,fixWellTh)
%% definitions
f = filesep;
inoc_plate_tbl = readtable(inoc_plate_file,'sheet',3,'range','B2:M9'); % Phage inoculation data
inoc_plate = inoc_plate_tbl.Variables;
inoc_plate(WT_pos) = 100; %WT, any number but -1.
no_phage_wells = find(reshape(inoc_plate,[96 1])==-1);
image_names = dir(strcat([infect_imgs_folder f] ,'*.CR2'));

if ~exist(infectStructFile,'file')

    % allocate pathes and define plqStruct    
    infectStruct.imgFolder = infect_imgs_folder;
    infectStruct.resFolder = save_folder;
    infectStruct.inocXlsFile = inoc_plate_file;
    infectStruct.inoculation = inoc_plate;
    infectStruct.anaDate = datetime;
    infectStruct.FullBacNms = readtable(name_order_file,'sheet',1,'ReadVariableNames',false);
    infectStruct.FullPhgNms = readtable(name_order_file,'sheet',exp+1,'ReadVariableNames',false);
    infectStruct.params = struct('init_thresh',[],...
        'wellSize',wellSize,...
        'drops_centers',[],...
        'min_plq',min_plq);
    infectStruct.plaques = struct('bacIsoName', {},...
        'plaqueMatrix', {}, ...
        'thresh', {}, ...
        'normalized_plate',{},...
        'takeWell',{});

    % Find well centers:
    if ~isfile([save_folder f 'drops_centers.mat'])
        drops_centers = get_plaque_centers(infect_imgs_folder, [save_folder f]);
    else
        load([save_folder f 'drops_centers.mat']);
    end
    infectStruct.params.drops_centers = drops_centers;

    % Interpolate all plates based on no-phage areas to smooth uneven fluorescence imaging 
    % convert to uint8 according to the 90th percentile
    highFact = 1.45;
    for im = 1: size(image_names,1)   
        fprintf('Normalizing image %s...\n',image_names(im).name)
        image_org = imread(strcat(infect_imgs_folder,f,image_names(im).name));
        if image_names(im).name(end-6)=='R'
            ch = 1; 
        elseif image_names(im).name(end-6)=='Y'
            ch = 2;
        elseif image_names(im).name(end-6)=='C'
            ch = 3;
        end   
        image = fliplr(image_org(:,:,ch));
        plate_norm_inter = interpolate_plate(image,no_phage_wells,wellSize,drops_centers(:,1), drops_centers(:,2));
        wsR = wellSize*2-20;
        corner = 10;
        [plate_norm_well_int,normFactPerWell_int] = norm_well(plate_norm_inter,infectStruct,wsR,corner,highFact);
        infectStruct.plaques(im).normalized_plate = uint8(plate_norm_well_int);
        infectStruct.plaques(im).normFactor = normFactPerWell_int;
        infectStruct.plaques(im).bacIsoName = image_names(im).name(1:end-8);
    end
else
    load(infectStructFile)
    if exist('infectStruct1','var')
        infectStruct = infectStruct1;
    elseif exist('infectStruct2','var')
        infectStruct = infectStruct2;
    end
end
%% initialize takeWell field (wells with -1, due to merged phage spots, will not considered in the analysis)
for im = 1: size(image_names,1)   
    infectStruct.plaques(im).takeWell = ones(96,1);
end

%% Adjust a binarization threshold for each plate
close all;
init_thresh0 = 0.9; 
if fixPltTh
    im = 97; % Wildtype plate
    fig = figure(im); clf;
    fprintf('Adjusting image %s...\n',image_names(im).name)
    adjustPlateThresh(fig,infectStruct,im,init_thresh0,plateWT1_thresh_xls,1)
    drawnow
    waitfor(fig)
end
init_thresh_tbl = readtable(plateWT1_thresh_xls);
init_thresh = init_thresh_tbl.Var2;
if fixPltTh
    for im = 1: size(image_names,1)
        fig = figure(im); clf;
        fprintf('Adjusting image %s...\n',image_names(im).name)
        adjustPlateThresh(fig,infectStruct,im,init_thresh,plate_thresh_xls)
        drawnow
        waitfor(fig)
    end
end

%% Update plate threshold information into the struct
threshold_vec = table2array(readtable(sprintf('%s%sAdjusted_threshold.xls', infectStruct.resFolder, '\')));
for im = 1:size(image_names,1)
    infectStruct.plaques(im).threshold = threshold_vec(im,2);
end

%% add well threshold information
% Adjust a binarization threshold for each well
if ~exist(well_thresh_xls,'file') || fixWellTh
    fprintf('Calculating temporal infectivity...');
    for bac = 1:size(infectStruct.plaques,2) 
        well_threshold_plt = repmat(infectStruct.plaques(bac).threshold,1,96);
        infectStruct.plaques(bac).well_threshold = well_threshold_plt;
        infectStruct.plaques(bac).infectivity = calc_infectivity(infectStruct,bac,min_plq);
    end
    close all;
    fig = figure(1000); clf;
    ax = axes();
    infectStruct.params.min_plq = min_plq;
    adjustWellThresh(infectStruct,well_thresh_xls,ax);
    drawnow
    waitfor(fig)
end

well_thresh = readmatrix(well_thresh_xls);

for bac = 1:size(infectStruct.plaques,2)
    well_threshold_96 = repmat(infectStruct.plaques(bac).threshold,1,96);
    bac_lines = find(well_thresh(:,1)==bac);
    if ~isempty(bac_lines)
        well_threshold_96(well_thresh(bac_lines,2)) =  well_thresh(bac_lines,3);
    end
    infectStruct.plaques(bac).well_threshold = well_threshold_96;
end
%% Remove merged plaques
infectStruct = remove_merged_plqs(infectStruct,lids_folder,xls_remove_name );

%% Calculate final infectability
fprintf('Calculating infectivity...');
for bac = 1:size(infectStruct.plaques,2) 
    infectStruct.plaques(bac).infectivity = calc_infectivity(infectStruct,bac,min_plq);
    infectStruct.plaques(bac).turbidity = calc_turbidity(infectStruct,bac);
end

fprintf('done\n');

end

